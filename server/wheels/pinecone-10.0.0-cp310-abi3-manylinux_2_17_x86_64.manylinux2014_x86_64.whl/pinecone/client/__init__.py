"""Synchronous client implementations."""
